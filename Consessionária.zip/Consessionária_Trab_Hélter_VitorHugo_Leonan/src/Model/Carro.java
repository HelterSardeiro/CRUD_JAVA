/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import javax.swing.JOptionPane;

/**
 *
 * @author Samuelson
 */
public class Carro {
    
    private int id;
    private String marca;
    private String modelo;
    private int qtd;
    private double preco;
    private String garantia;

    public String getGarantia() {
        return garantia;
    }

    public void setGarantia(String garantia) {
        this.garantia = garantia;
    }
  
    public String getModelo() {
        return modelo;
    }
  
    public void setModelo(String modelo) throws Exception {
        if (modelo.length()>50)
        {
            throw new Exception("Tamanho do modelo fora do permitido");
            
        } else {
        this.modelo = modelo;
        }
    }
       public String getMarca() {
        return marca;
    }
    public void setMarca(String marca) throws Exception {
        
         if (marca.length()>50)
        {
            throw new Exception("Tamanho da marca fora do permitido");
            
        } else {
        this.marca = marca;
         }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    
    public int getQtd() {
        return qtd;
    }

    public void setQtd(int qtd) throws Exception {
        
        this.qtd = qtd;
       
    }    

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) throws Exception{
        
        this.preco = preco;
        
    }  
}

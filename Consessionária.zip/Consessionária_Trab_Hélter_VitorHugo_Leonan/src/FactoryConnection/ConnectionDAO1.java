/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FactoryConnection;
import DAO.ConnectionDAO;
import java.sql.Connection;

/**
 *
 * @author Helter
 */
public class ConnectionDAO1 extends ConnectionDAO {
    private final String url = "jdbc:mysql://localhost/banco1";
    private final String user = "root";
    private final String pass = "";
    Connection conn = null;
    
    public Connection getConnection() {
        conn = this.getConnection(url, user, pass);
        return conn;
    }
   
    
}


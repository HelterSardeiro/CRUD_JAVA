/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FactoryConnection;
import DAO.ConnectionDAO;
import java.sql.Connection;

/**
 *
 * @author Helter
 */
public class ConnectionDAO2 extends ConnectionDAO{
    private final String url = "jdbc:mysql://localhost/banco2";
    //Usuario novo
    //Se o codigo não funcionar no bd 2 é por conta do usuario que deve ser criado
    private final String user = "helter";
    //agora com senha
    private final String pass = "12345678";
    Connection conn = null;
    
    public Connection getConnection() {
        conn = this.getConnection(url, user, pass);
        return conn;
    }
}


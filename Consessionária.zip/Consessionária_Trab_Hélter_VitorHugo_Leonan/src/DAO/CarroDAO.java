/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import Model.Carro;
import FactoryConnection.*;

/**
 *
 * @author Helter
 */
public class CarroDAO {
    Connection con = null;
    
    public CarroDAO(String banco){
        if(banco.equals("BANCO1")){
            con = new ConnectionDAO1().getConnection();
        }
        else if(banco.equals("BANCO2")){
            con = new ConnectionDAO2().getConnection();
        }
    }
    
 
    public void create(Carro p) {

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO Concessionária (marca,modelo,qtd,preco,garantia)VALUES(?,?,?,?,?)");
            stmt.setString(1, p.getMarca());
            stmt.setString(2, p.getModelo());
            stmt.setInt(3, p.getQtd());
            stmt.setDouble(4, p.getPreco());
            stmt.setString(5, p.getGarantia());

            stmt.executeUpdate();

            
       
            stmt.close();
            
            
            JOptionPane.showMessageDialog(null, "Cadastrado com sucesso!");
        } catch(Exception ex){
                JOptionPane.showMessageDialog(null, "Ocorreu um erro!");
                throw new RuntimeException(ex);
                
         }

    }
   
    public List<Carro> read() throws Exception {

        PreparedStatement stmt = null;
        ResultSet rs = null;

        
        List<Carro> produtos = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM concessionária");
            rs = stmt.executeQuery();

            while (rs.next()) {

                Carro produto = new Carro();

                produto.setId(rs.getInt("id"));
                produto.setMarca(rs.getString("marca"));
                produto.setModelo(rs.getString("modelo"));
                produto.setQtd(rs.getInt("qtd"));
                produto.setPreco(rs.getDouble("preco"));
                produto.setGarantia(rs.getString("garantia"));
                produtos.add(produto);
            }

    
            con.close();
            stmt.close();
            rs.close();
            
          } catch (Exception ex) {
            throw new RuntimeException(ex);
        }

        return produtos;

    }
    public List<Carro> readForDesc(String desc) throws Exception {

        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Carro> carros = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM Concessionária WHERE marca LIKE ?");
            stmt.setString(1, "%"+desc+"%");
            
            rs = stmt.executeQuery();

            while (rs.next()) {

                Carro carro = new Carro();

                carro.setId(rs.getInt("id"));
                carro.setMarca(rs.getString("marca"));
                carro.setModelo(rs.getString("modelo"));
                carro.setQtd(rs.getInt("qtd"));
                carro.setPreco(rs.getDouble("preco"));
                carro.setGarantia(rs.getString("garantia"));
                carros.add(carro);
            }

        stmt.close();
            
            JOptionPane.showMessageDialog(null, "Busca realizada com sucesso!");
        } catch(Exception ex){
            throw new RuntimeException(ex);
        }

        return carros;

    }

    public void update(Carro p) {

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("UPDATE Concessionária SET marca = ? ,modelo = ? ,qtd = ?,preco = ?,garantia=? WHERE id = ?");
            stmt.setString(1, p.getMarca());
            stmt.setString(2,p.getModelo());
            stmt.setInt(3, p.getQtd());
            stmt.setDouble(4, p.getPreco());
            stmt.setString(5,p.getGarantia());
            stmt.setInt(6, p.getId());

            stmt.executeUpdate();

            stmt.close();
            
            
            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
    public void delete(Carro p) {

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("DELETE FROM Concessionária WHERE id = ?");
            stmt.setInt(1, p.getId());

            stmt.executeUpdate();

              stmt.close();
            
            
            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
}

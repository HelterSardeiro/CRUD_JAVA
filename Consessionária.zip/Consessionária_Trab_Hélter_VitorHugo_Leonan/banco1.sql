create database banco1;
use banco1;
CREATE TABLE Concessionária (
    id Integer auto_increment primary key,
    marca varchar (50) not null,
    modelo varchar (50) not null,
    qtd integer not null,
    preco double not null,
    garantia varchar(50) not null
);
select * from Concessionária;
